class OptionsManager {
  constructor() {
    this.settings = {};
    this.themeBasePreset = 'pink';
    this.colorHistory = [];
    this.lastPickedColor = null;
    this.activePickedTarget = '';
    this.init();
  }

  async init() {
    await this.loadSettings();
    this.updateAppVersionLabel();
    this.bindEvents();
    this.updateUI();
  }

  updateAppVersionLabel() {
    const el = document.getElementById('appVersionLabel');
    if (!el) return;
    const version = (chrome.runtime?.getManifest()?.version) || '0.0.0';
    el.textContent = `Pixel Color Picker v${version}`;
  }

  getThemePresets() {
    return window.PixelThemes.getThemePresets();
  }

  getDefaultSettings() {
    return {
      defaultFormat: 'hex',
      pickAction: 'save',
      autoSave: true,
      maxColorsPerPalette: 20,
      language: 'zh-CN',
      themePreset: 'pink',
      themeBasePreset: 'pink',
      headerColor: '#ff6b9d',
      buttonColor: '#ff6b9d',
      bgColor: '#fff9fc',
      panelColor: '#ffffff'
    };
  }

  async loadSettings() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(['settings', 'colorHistory', 'lastPickedColor'], (result) => {
        this.settings = {
          ...this.getDefaultSettings(),
          ...(result.settings || {})
        };
        this.colorHistory = Array.isArray(result.colorHistory) ? result.colorHistory : [];
        this.lastPickedColor = result.lastPickedColor || null;
        this.themeBasePreset = this.settings.themeBasePreset || 'pink';
        resolve();
      });
    });
  }

  async saveSettings() {
    return new Promise((resolve) => {
      chrome.storage.sync.set({ settings: this.settings }, resolve);
    });
  }

  getThemeSettings() {
    const presets = this.getThemePresets();
    const baseKey = this.settings.themePreset === 'custom'
      ? (this.settings.themeBasePreset || 'pink')
      : (presets[this.settings.themePreset] ? this.settings.themePreset : 'pink');
    const base = window.PixelThemes.mergeTheme(presets[baseKey] || presets.pink);
    return {
      themePreset: this.settings.themePreset || baseKey,
      themeBasePreset: baseKey,
      headerColor: this.settings.headerColor || base.headerColor,
      buttonColor: this.settings.buttonColor || base.buttonColor,
      bgColor: this.settings.bgColor || base.bgColor,
      panelColor: this.settings.panelColor || base.panelColor
    };
  }

  updateUI() {
    const theme = this.getThemeSettings();
    this.themeBasePreset = theme.themeBasePreset;

    document.getElementById('defaultFormat').value = this.settings.defaultFormat;
    document.getElementById('pickAction').value = this.settings.pickAction;
    document.getElementById('autoSave').checked = this.settings.autoSave !== false;
    document.getElementById('maxColors').value = this.settings.maxColorsPerPalette || 20;
    document.getElementById('languageSelect').value = this.settings.language || 'zh-CN';
    document.getElementById('themePreset').value = theme.themePreset;
    document.getElementById('headerColor').value = theme.headerColor;
    document.getElementById('buttonColor').value = theme.buttonColor;
    document.getElementById('bgColor').value = theme.bgColor;
    document.getElementById('panelColor').value = theme.panelColor;

    this.syncColorLabels();
    this.renderThemeColorHistory();
    this.applyTheme();
    this.applyI18n();
  }

  bindEvents() {
    document.getElementById('saveSettings').addEventListener('click', () => this.handleSave());
    document.getElementById('resetSettings').addEventListener('click', () => this.handleReset());
    document.getElementById('backToPopup').addEventListener('click', () => window.close());
    document.getElementById('useLastPicked').addEventListener('click', () => this.useLastPickedForTheme());
    document.getElementById('clearThemeColorHistory')?.addEventListener('click', () => this.clearThemeSourceColors());
    document.getElementById('closePickedTarget').addEventListener('click', () => this.closePickedTargetPanel());
    document.getElementById('pickedTargetPanel').addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
    });
    document.querySelectorAll('.use-picked-btn').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.openPickedTargetPanel(button.dataset.targetColor);
      });
    });

    document.getElementById('themePreset').addEventListener('change', () => this.applyThemePresetToInputs());
    ['headerColor', 'buttonColor', 'bgColor', 'panelColor'].forEach((id) => {
      document.getElementById(id).addEventListener('input', () => {
        const presetSelect = document.getElementById('themePreset');
        if (presetSelect.value !== 'custom') this.themeBasePreset = presetSelect.value;
        presetSelect.value = 'custom';
        this.syncColorLabels();
        this.applyThemeFromInputs();
      });
    });

    ['defaultFormat', 'pickAction', 'autoSave', 'maxColors', 'languageSelect'].forEach((id) => {
      document.getElementById(id).addEventListener('change', async () => {
        this.collectSettingsFromInputs();
        if (id === 'languageSelect') {
          this.applyI18n();
          await this.saveSettings();
        }
      });
    });

    document.getElementById('exportData').addEventListener('click', () => this.exportData());
    document.getElementById('importData').addEventListener('click', () => this.importData());
    document.getElementById('clearData').addEventListener('click', () => this.clearData());
    document.getElementById('viewHistory').addEventListener('click', () => this.viewHistory());
    this.bindChangelogEvents();
  }

  collectSettingsFromInputs() {
    const maxVal = parseInt(document.getElementById('maxColors').value, 10) || 20;
    this.settings = {
      ...this.settings,
      defaultFormat: document.getElementById('defaultFormat').value,
      pickAction: document.getElementById('pickAction').value,
      autoSave: document.getElementById('autoSave').checked,
      maxColorsPerPalette: Math.max(1, Math.min(100, maxVal)),
      language: document.getElementById('languageSelect').value,
      themePreset: document.getElementById('themePreset').value,
      themeBasePreset: this.themeBasePreset || 'pink',
      headerColor: document.getElementById('headerColor').value,
      buttonColor: document.getElementById('buttonColor').value,
      bgColor: document.getElementById('bgColor').value,
      panelColor: document.getElementById('panelColor').value
    };
  }

  getLanguage() {
    return window.PixelI18n?.normalize(this.settings.language || 'zh-CN') || 'zh-CN';
  }

  t(key) {
    return window.PixelI18n?.t(this.getLanguage(), key) || key;
  }

  applyI18n() {
    if (!window.PixelI18n) return;
    const language = this.getLanguage();
    document.documentElement.lang = language;
    document.title = `${this.t('setup')} - Pixel Color Picker`;
    window.PixelI18n.applyMap(document, language, {
      text: {
        '.pixel-header h1': 'appSettings',
        '.settings-nav a[href="#behavior"]': 'behavior',
        '.settings-nav a[href="#theme"]': 'theme',
        '.settings-nav a[href="#donate"]': 'donate',
        '.settings-nav a[href="#language"]': 'language',
        '.settings-nav a[href="#data"]': 'data',
        '.settings-nav a[href="#about"]': 'about',
        '#behavior .section-head h2': 'behaviorSettings',
        '#theme .section-head h2': 'themeAppearance',
        '#donate .section-head h2': 'donate',
        '#language .section-head h2': 'languageSettings',
        '#data .section-head h2': 'dataManagement',
        '#about .section-head h2': 'about',
        '#behavior .setting-item:nth-of-type(1) strong': 'defaultCopyFormat',
        '#behavior .setting-item:nth-of-type(1) small': 'defaultCopyFormatHint',
        '#behavior .setting-item:nth-of-type(2) strong': 'afterPickAction',
        '#behavior .setting-item:nth-of-type(2) small': 'afterPickActionHint',
        '#behavior .setting-item:nth-of-type(3) strong': 'autoSave',
        '#behavior .setting-item:nth-of-type(3) small': 'autoSaveHint',
        '#behavior .setting-item:nth-of-type(4) strong': 'paletteLimit',
        '#behavior .setting-item:nth-of-type(4) small': 'paletteLimitHint',
        '.theme-preset-block strong': 'themePreset',
        '.theme-preset-block small': 'themePresetHint',
        '.theme-custom-block .theme-block-head strong': 'customColors',
        '.theme-custom-block .theme-block-head small': 'customColorsHint',
        '.color-item:nth-of-type(1) > span': 'headerColor',
        '.color-item:nth-of-type(2) > span': 'buttonColor',
        '.color-item:nth-of-type(3) > span': 'bgColor',
        '.color-item:nth-of-type(4) > span': 'panelColor',
        '#pickedTargetTitle': 'chooseColor',
        '#targetColorHistory .picked-empty': 'noPickedHistory',
        '.picked-theme-head strong': 'generateThemeFromPicked',
        '#useLastPicked': 'useRecentPicked',
        '#themeColorHistory .picked-empty': 'noPickedHistory',
        '.theme-preview-block .theme-block-head strong': 'livePreview',
        '.theme-preview-block .theme-block-head small': 'saveSyncPopup',
        '#previewButton': 'buttonColor',
        '.preview-body strong': 'defaultPalette',
        '.preview-body small': 'themeSyncPopup',
        '#language .setting-item strong': 'uiLanguage',
        '#language .setting-item small': 'languageHint',
        '#exportData': 'exportAllData',
        '#importData': 'importData',
        '#clearData': 'clearAllData',
        '.about-info p:nth-child(2)': 'cuteToolDesc',
        '.about-info p:nth-child(3)': 'copyright',
        '#viewHistory': 'viewChangelog',
        '#saveSettings': 'saveSettings',
        '#resetSettings': 'reset',
        '#backToPopup': 'close'
      },
      title: {
        '.use-picked-btn': 'usePickedFill'
      },
      aria: {
        '.settings-nav': 'settingsGroup',
        '.use-picked-btn': 'usePickedFill'
      }
    });
    document.querySelector('#pickAction option[value="save"]').textContent = this.t('save');
    document.querySelector('#pickAction option[value="preview"]').textContent = this.t('preview');
    document.querySelector('#pickAction option[value="copy"]').textContent = this.t('copy');
    document.querySelector('#pickAction option[value="copy-save"]').textContent = this.t('copySave');
    this.updateThemePresetLabels('themePreset');
    this.updateSectionNumbers();
  }

  updateSectionNumbers() {
    ['behavior', 'theme', 'donate', 'language', 'data', 'about'].forEach((id, index) => {
      const badge = document.querySelector(`#${id} .section-head span`);
      if (badge) badge.textContent = String(index + 1).padStart(2, '0');
    });
  }

  updateThemePresetLabels(selectId) {
    const select = document.getElementById(selectId);
    if (!select) return;
    const lang = window.PixelI18n.normalize(this.settings.language || 'zh-CN');
    const order = window.PixelThemes.getThemeOrder();
    const prev = select.value;
    select.innerHTML = '';
    order.forEach((key) => {
      const option = document.createElement('option');
      option.value = key;
      option.textContent = window.PixelThemes.getThemeLabel(key, lang);
      select.appendChild(option);
    });
    if (order.includes(prev)) select.value = prev;
  }

  applyThemePresetToInputs() {
    const preset = document.getElementById('themePreset').value;
    const colors = this.getThemePresets()[preset];
    if (!colors) {
      this.syncColorLabels();
      this.applyThemeFromInputs();
      return;
    }
    this.themeBasePreset = preset;
    document.getElementById('headerColor').value = colors.headerColor;
    document.getElementById('buttonColor').value = colors.buttonColor;
    document.getElementById('bgColor').value = colors.bgColor;
    document.getElementById('panelColor').value = colors.panelColor;
    this.syncColorLabels();
    this.applyThemeFromInputs();
  }

  syncColorLabels() {
    ['headerColor', 'buttonColor', 'bgColor', 'panelColor'].forEach((id) => {
      document.getElementById(`${id}Value`).textContent = document.getElementById(id).value.toUpperCase();
    });
  }

  renderThemeColorHistory() {
    const list = document.getElementById('themeColorHistory');
    if (!list) return;

    const recent = this.getRecentThemeSourceColors();
    if (recent.length === 0) {
      list.innerHTML = `<span class="picked-empty">${this.t('noPickedHistory')}</span>`;
      return;
    }

    list.innerHTML = recent.map((color) => `
      <div class="picked-color-wrap">
        <button type="button"
                class="picked-color"
                data-hex="${color.hex}"
                style="background:${color.hex}"
                title="${this.getLanguage() === 'en' ? `Generate theme from ${color.hex}` : `用 ${color.hex} 生成主题`}"></button>
        <button type="button"
                class="picked-color-delete"
                data-hex="${color.hex}"
                title="${this.t('deleteColor')}">×</button>
      </div>
    `).join('');

    list.querySelectorAll('.picked-color').forEach((button) => {
      button.addEventListener('click', () => this.generateThemeFromHex(button.dataset.hex));
    });
    list.querySelectorAll('.picked-color-delete').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        this.deleteThemeSourceColor(button.dataset.hex);
      });
    });
  }

  getRecentThemeSourceColors() {
    const colors = [];
    if (this.lastPickedColor?.hex) colors.push(this.lastPickedColor);
    this.colorHistory.forEach((color) => {
      if (color?.hex && !colors.some((item) => item.hex === color.hex)) colors.push(color);
    });
    return colors.slice(0, 6);
  }

  openPickedTargetPanel(targetId) {
    if (!['headerColor', 'buttonColor', 'bgColor', 'panelColor'].includes(targetId)) return;
    const panel = document.getElementById('pickedTargetPanel');
    if (this.activePickedTarget === targetId && panel && !panel.hidden) {
      this.closePickedTargetPanel();
      return;
    }

    this.closePickedTargetPanel();

    this.activePickedTarget = targetId;
    const title = document.getElementById('pickedTargetTitle');
    const input = document.getElementById(targetId);
    const item = input?.closest('.color-item');
    const trigger = document.querySelector(`.use-picked-btn[data-target-color="${targetId}"]`);
    const labels = {
      headerColor: `${this.t('chooseColor')}: ${this.t('headerColor')}`,
      buttonColor: `${this.t('chooseColor')}: ${this.t('buttonColor')}`,
      bgColor: `${this.t('chooseColor')}: ${this.t('bgColor')}`,
      panelColor: `${this.t('chooseColor')}: ${this.t('panelColor')}`
    };
    if (!panel || !item) return;

    title.textContent = labels[targetId];
    item.classList.add('is-picking');
    trigger?.classList.add('is-active');
    item.appendChild(panel);
    this.renderTargetColorHistory();
    panel.hidden = false;
  }

  closePickedTargetPanel() {
    this.activePickedTarget = '';
    document.querySelectorAll('.color-item.is-picking').forEach((item) => item.classList.remove('is-picking'));
    document.querySelectorAll('.use-picked-btn.is-active').forEach((button) => button.classList.remove('is-active'));
    const panel = document.getElementById('pickedTargetPanel');
    if (panel) panel.hidden = true;
  }

  renderTargetColorHistory() {
    const list = document.getElementById('targetColorHistory');
    if (!list) return;
    const recent = this.getRecentThemeSourceColors();
    if (recent.length === 0) {
      list.innerHTML = `<span class="picked-empty">${this.t('noPickedHistory')}</span>`;
      return;
    }

    list.innerHTML = recent.map((color) => `
      <div class="picked-color-wrap">
        <button type="button"
                class="picked-color"
                data-hex="${color.hex}"
                style="background:${color.hex}"
                title="${this.getLanguage() === 'en' ? `Use ${color.hex}` : `使用 ${color.hex}`}"></button>
        <button type="button"
                class="picked-color-delete"
                data-hex="${color.hex}"
                title="${this.t('deleteColor')}">×</button>
      </div>
    `).join('');

    list.querySelectorAll('.picked-color').forEach((button) => {
      button.addEventListener('click', () => this.applyPickedColorToTarget(button.dataset.hex));
    });
    list.querySelectorAll('.picked-color-delete').forEach((button) => {
      button.addEventListener('click', (event) => {
        event.stopPropagation();
        this.deleteThemeSourceColor(button.dataset.hex);
      });
    });
  }

  applyPickedColorToTarget(hex) {
    if (!this.activePickedTarget) return;
    const input = document.getElementById(this.activePickedTarget);
    if (!input) return;
    input.value = hex.toUpperCase();
    document.getElementById('themePreset').value = 'custom';
    this.syncColorLabels();
    this.applyThemeFromInputs();
    this.closePickedTargetPanel();
    this.showNotification(this.getLanguage() === 'en' ? `Filled ${hex.toUpperCase()}` : `已填入 ${hex.toUpperCase()}`);
  }

  useLastPickedForTheme() {
    const hex = this.lastPickedColor?.hex || this.colorHistory[0]?.hex;
    if (!hex) {
      this.showNotification(this.t('noPickedHistory'));
      return;
    }
    this.generateThemeFromHex(hex);
  }

  saveColorHistory() {
    return new Promise((resolve) => {
      chrome.storage.sync.set(
        { colorHistory: this.colorHistory, lastPickedColor: this.lastPickedColor },
        resolve
      );
    });
  }

  async deleteThemeSourceColor(hex) {
    const upperHex = hex.toUpperCase();
    const before = this.colorHistory.length;
    const hadLastPicked = this.lastPickedColor?.hex?.toUpperCase() === upperHex;
    this.colorHistory = this.colorHistory.filter((item) => item.hex?.toUpperCase() !== upperHex);
    if (hadLastPicked) {
      this.lastPickedColor = null;
    }
    if (this.colorHistory.length === before && !hadLastPicked) return;
    await this.saveColorHistory();
    this.renderThemeColorHistory();
    this.renderTargetColorHistory();
    this.showNotification(this.t('recentColorDeleted'));
  }

  async openConfirmDialog({ eyebrow = '', title = '', message = '', actions = [] } = {}) {
    return new Promise((resolve) => {
      const overlay = document.getElementById('confirmOverlay');
      document.getElementById('confirmEyebrow').textContent = eyebrow;
      document.getElementById('confirmTitle').textContent = title;
      document.getElementById('confirmBody').textContent = message;
      const footer = document.getElementById('confirmFooter');
      footer.innerHTML = '';
      actions.forEach((action) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `pixel-dialog-button ${action.tone || ''}`.trim();
        button.textContent = action.label;
        button.addEventListener('click', () => {
          overlay.hidden = true;
          resolve({ action: action.id });
        });
        footer.appendChild(button);
      });
      document.getElementById('confirmClose').onclick = () => {
        overlay.hidden = true;
        resolve({ action: 'cancel' });
      };
      overlay.hidden = false;
    });
  }

  async clearThemeSourceColors() {
    const result = await this.openConfirmDialog({
      eyebrow: 'PIXEL CLEAR',
      title: this.t('clearHistory'),
      message: this.t('clearHistoryMessage'),
      actions: [
        { id: 'confirm', label: this.t('clear'), tone: 'danger' },
        { id: 'cancel', label: this.t('cancel') }
      ]
    });
    if (result.action !== 'confirm') return;
    this.colorHistory = [];
    this.lastPickedColor = null;
    await this.saveColorHistory();
    this.renderThemeColorHistory();
    this.renderTargetColorHistory();
    this.showNotification(this.t('historyCleared'));
  }

  generateThemeFromHex(hex) {
    const rgb = this.hexToRgb(hex);
    if (!rgb) return;

    const header = this.rgbToHex(rgb.r, rgb.g, rgb.b);
    const button = this.rgbToHex(
      this.mixChannel(rgb.r, 255, 0.22),
      this.mixChannel(rgb.g, 255, 0.22),
      this.mixChannel(rgb.b, 255, 0.22)
    );
    const bg = this.rgbToHex(
      this.mixChannel(rgb.r, 255, 0.92),
      this.mixChannel(rgb.g, 255, 0.92),
      this.mixChannel(rgb.b, 255, 0.92)
    );
    const panel = this.rgbToHex(
      this.mixChannel(rgb.r, 255, 0.97),
      this.mixChannel(rgb.g, 255, 0.97),
      this.mixChannel(rgb.b, 255, 0.97)
    );

    document.getElementById('themePreset').value = 'custom';
    this.themeBasePreset = 'pink';
    document.getElementById('headerColor').value = header;
    document.getElementById('buttonColor').value = button;
    document.getElementById('bgColor').value = bg;
    document.getElementById('panelColor').value = panel;
    this.syncColorLabels();
    this.applyThemeFromInputs();
    this.showNotification(this.getLanguage() === 'en' ? `Theme generated from ${header}` : `已用 ${header} 生成主题`);
  }

  hexToRgb(hex) {
    const match = /^#?([0-9a-f]{6})$/i.exec(hex || '');
    if (!match) return null;
    const value = match[1];
    return {
      r: parseInt(value.slice(0, 2), 16),
      g: parseInt(value.slice(2, 4), 16),
      b: parseInt(value.slice(4, 6), 16)
    };
  }

  mixChannel(from, to, amount) {
    return Math.round(from + (to - from) * amount);
  }

  rgbToHex(r, g, b) {
    return `#${[r, g, b].map((value) => {
      return Math.max(0, Math.min(255, value)).toString(16).padStart(2, '0');
    }).join('')}`.toUpperCase();
  }

  applyThemeFromInputs() {
    this.collectSettingsFromInputs();
    this.applyTheme();
  }

  async handleSave() {
    this.collectSettingsFromInputs();
    await this.saveSettings();
    this.applyTheme();
    this.applyI18n();
    this.showNotification(this.t('settingsSaved'));
  }

  async handleReset() {
    this.settings = this.getDefaultSettings();
    this.themeBasePreset = 'pink';
    this.updateUI();
    await this.saveSettings();
    this.showNotification(this.t('settingsReset'));
  }

  async exportData() {
    const data = await new Promise((resolve) => {
      chrome.storage.sync.get(null, resolve);
    });

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'pixel-color-picker-backup.json';
    link.click();
    URL.revokeObjectURL(url);
    this.showNotification(this.t('dataExported'));
  }

  importData() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';

    input.onchange = async (event) => {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = async (readerEvent) => {
        try {
          const data = JSON.parse(readerEvent.target.result);
          await new Promise((resolve) => {
            chrome.storage.sync.set(data, resolve);
          });
          await this.loadSettings();
          this.updateUI();
          this.showNotification(this.t('dataImported'));
        } catch (error) {
          this.showNotification(this.t('importFailed'));
        }
      };
      reader.readAsText(file);
    };

    input.click();
  }

  async clearData() {
    if (!confirm(this.t('clearDataConfirm'))) return;

    await new Promise((resolve) => {
      chrome.storage.sync.clear(resolve);
    });
    await this.loadSettings();
    this.updateUI();
    this.showNotification(this.t('allDataCleared'));
  }

  viewHistory() {
    this.showChangelog();
  }

  getChangelogEntries() {
    const language = this.getLanguage();
    const manifestVersion = (chrome.runtime.getManifest()?.version) || '0.0.0';
    const entries = [
      {
        version: `v${manifestVersion}`,
        items: language === 'en'
          ? [
              { kind: 'feat', text: 'Theme system refactor: extracted shared/themes.js, unified dropdowns, fallback for missing fields' },
              { kind: 'feat', text: 'Added 3 new themes: Rose, Forest, Holly' },
              { kind: 'feat', text: 'Export enhancements: CSV, copy all HEX, Adobe ASE' },
              { kind: 'feat', text: 'Color history supports favorite-to-top and full CSV export' },
              { kind: 'feat', text: 'New after-pick action: pick and close popup' },
              { kind: 'fix', text: 'Fixed settings label typo where "Theme preset" was shown as "Header color"' },
              { kind: 'fix', text: 'Fixed color history delete buttons not responding and swatch compression' },
              { kind: 'fix', text: 'Clear history confirmation replaced with inline pixel-style dialog' },
              { kind: 'feat', text: 'Globally hidden scrollbars in popup and pixel-art scrollbar for changelog/history' },
              { kind: 'feat', text: 'Pick entry adjusted: removed global shortcut, kept popup button and right-click menu "Pick and save with Pixel"' }
            ]
          : [
              { kind: 'feat', text: '主题系统重构：抽离 shared/themes.js，统一 popup / options 主题下拉与缺字段兜底' },
              { kind: 'feat', text: '新增三套主题：烟熏玫瑰 rose、苍松翠谷 forest、冬青红果 holly' },
              { kind: 'feat', text: '导出增强：新增 CSV、复制全部 HEX、Adobe ASE 格式' },
              { kind: 'feat', text: '历史记录支持收藏置顶与整段导出 CSV' },
              { kind: 'feat', text: '取色后动作新增「取色并关闭 popup」选项' },
              { kind: 'fix', text: '修复设置项「主题预设」误写为「标题色」的文案问题' },
              { kind: 'fix', text: '修复取色历史删除按钮无反应、历史方块压缩等问题' },
              { kind: 'fix', text: '清空取色历史确认改为内联像素弹窗' },
              { kind: 'feat', text: 'popup / 更新日志 / 历史记录滚动条全局隐藏并支持像素风样式' },
              { kind: 'feat', text: '取色入口调整：移除全局快捷键，仅保留 popup 按钮与右键菜单「用 Pixel 吸色并保存」' }
            ]
      },
      {
        version: 'v1.1.1',
        items: language === 'en'
          ? [
              { kind: 'new', text: 'Built-in changelog popup in settings (pixel-style design)' },
              { kind: 'new', text: 'Feedback email entry inside the changelog dialog' },
              { kind: 'fix', text: 'Changelog dialog white text contrast fixed under pink theme' },
              { kind: 'fix', text: 'Close button no longer disappears/turns white on hover' },
              { kind: 'feat', text: 'Removed tip entry from popup; kept it only in options' }
            ]
          : [
              { kind: 'new', text: '设置页新增内置更新日志（像素风弹窗），版本自动从 manifest 读取' },
              { kind: 'new', text: '更新日志弹窗内新增反馈邮件入口' },
              { kind: 'fix', text: '粉主题下更新日志弹窗白字看不清问题修复' },
              { kind: 'fix', text: '关闭按钮悬浮不再消失/变白' },
              { kind: 'feat', text: '移除 popup 内打赏入口，仅在 options 设置页保留' }
            ]
      },
      {
        version: 'v1.1.0',
        items: language === 'en'
          ? [
              { kind: 'feat', text: 'Removed Pro plan gating, all themes and unlimited palettes available to everyone' },
              { kind: 'feat', text: 'Optional tips - WeChat QR / PayPal donation links' },
              { kind: 'feat', text: 'Zero remote - removed all host_permissions' },
              { kind: 'chore', text: 'Removed 18+ Pro-related i18n keys and 4 Pro-limit intercepts' }
            ]
          : [
              { kind: 'feat', text: '移除 Pro 限制，所有主题与无限色卡向所有用户开放' },
              { kind: 'feat', text: '新增打赏 - 微信赞赏码 / PayPal 付款链接（可选）' },
              { kind: 'feat', text: '零远程 - 删除所有 host_permissions' },
              { kind: 'chore', text: '删除 18+ Pro 相关 i18n 字段与 4 处 Pro 限制拦截' }
            ]
      },
      {
        version: 'v1.0.0',
        items: language === 'en'
          ? [
              { kind: 'feat', text: 'Pixel-style popup' },
              { kind: 'feat', text: 'Palette management, history, import & export' },
              { kind: 'feat', text: 'Theme presets and custom themes' }
            ]
          : [
              { kind: 'feat', text: '像素风 popup' },
              { kind: 'feat', text: '色卡管理、历史记录、导入导出' },
              { kind: 'feat', text: '主题预设与自定义主题' }
            ]
      }
    ];

    const titleMap = { feat: 'feat', fix: 'fix', new: 'new', chore: 'chore' };
    return entries.map((entry) => ({
      version: entry.version,
      items: entry.items.map((item) => ({
        kind: titleMap[item.kind] || 'feat',
        text: item.text
      }))
    }));
  }

  showChangelog() {
    const overlay = document.getElementById('changelogOverlay');
    const body = document.getElementById('changelogBody');
    if (!overlay || !body) return;

    const entries = this.getChangelogEntries();
    body.innerHTML = entries.map((entry) => `
      <div class="changelog-version">
        <div class="changelog-version-tag">${entry.version}</div>
        <ul class="changelog-list">
          ${entry.items.map((item) => `
            <li class="changelog-item changelog-${item.kind}">
              <span class="changelog-bullet"></span>${item.text}
            </li>`).join('')}
        </ul>
      </div>
    `).join('');

    const subject = this.getLanguage() === 'en'
      ? 'Pixel Color Picker Feedback'
      : '像素吸色器 · 问题反馈';
    const feedback = document.getElementById('feedbackMailBtn');
    if (feedback) {
      feedback.href = `mailto:huangzero2004@gmail.com?subject=${encodeURIComponent(subject)}`;
    }

    overlay.hidden = false;
  }

  hideChangelog() {
    const overlay = document.getElementById('changelogOverlay');
    if (overlay) overlay.hidden = true;
  }

  bindChangelogEvents() {
    const overlay = document.getElementById('changelogOverlay');
    if (!overlay) return;
    document.getElementById('changelogClose')?.addEventListener('click', () => this.hideChangelog());
    document.getElementById('changelogDismiss')?.addEventListener('click', () => this.hideChangelog());
    overlay.addEventListener('click', (event) => {
      if (event.target.id === 'changelogOverlay') this.hideChangelog();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && !overlay.hidden) this.hideChangelog();
    });
  }

  showNotification(message) {
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.style.opacity = '0';
      notification.style.transition = 'opacity 0.3s';
      setTimeout(() => notification.remove(), 300);
    }, 1800);
  }

  applyTheme() {
    const presets = this.getThemePresets();
    const presetKey = this.settings.themePreset === 'custom'
      ? this.settings.themeBasePreset
      : this.settings.themePreset;
    const preset = window.PixelThemes.mergeTheme(presets[presetKey] || presets.pink);
    const root = document.documentElement;
    const headerColor = this.settings.headerColor || preset.headerColor;
    const buttonColor = this.settings.buttonColor || preset.buttonColor;
    const bgColor = this.settings.bgColor || preset.bgColor;
    const panelColor = this.settings.panelColor || preset.panelColor;

    root.style.setProperty('--header-bg', headerColor);
    root.style.setProperty('--button-bg', buttonColor);
    root.style.setProperty('--primary', buttonColor);
    root.style.setProperty('--bg', bgColor);
    root.style.setProperty('--panel', panelColor);
    root.style.setProperty('--panel-warm', preset.panelWarmColor || panelColor);
    root.style.setProperty('--bg-dot', preset.bgDotColor);
    root.style.setProperty('--bg-line', preset.bgLineColor);
    root.style.setProperty('--text', preset.textColor);
    root.style.setProperty('--text-soft', preset.textSoftColor);
    root.style.setProperty('--border', preset.borderColor);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new OptionsManager();
});
